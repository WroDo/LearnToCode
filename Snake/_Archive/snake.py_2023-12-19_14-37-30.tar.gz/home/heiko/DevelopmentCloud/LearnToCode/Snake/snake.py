# Nah: https://docs.python.org/3/howto/curses.html
# Yeah: https://www.pygame.org/docs/
## apt-get install python3-pygame

import pygame
import random

# globals
gScreenSizeX=640;
gScreenSizeY=480;
pygame.init()
gRunning = True
gColorBackground="black"
gRectangleSize=20
gSnakeXPositions=list()
gSnakeYPositions=list()
gSnakeXPositions.append(int(gScreenSizeX/2)-1) # origin is top left
gSnakeYPositions.append(int(gScreenSizeY/2)-1) # we are starting in the middle of the surface
gDirection="right"
gTilesX=int(gScreenSizeX / gRectangleSize)
gTilesY=int(gScreenSizeY / gRectangleSize)
#gPowerpillPosition=pygame.Vector2((random.randrange(1,640) % gRectangleSize)*gRectangleSize-1, (random.randrange(1,480) % gRectangleSize)*gRectangleSize -1)
gPowerpillPosition=pygame.Vector2(random.randrange(1,gTilesX-1)*gRectangleSize-1, random.randrange(1,gTilesY-1)*gRectangleSize-1)
print("gPowerpillPosition: " + str(gPowerpillPosition))
gPowerpillCounter=0
gFontSize=36
gScore=0
gColorText="white"

# pygame setup
gScreen = pygame.display.set_mode((gScreenSizeX, gScreenSizeY))
gClock = pygame.time.Clock()
gFont = pygame.font.Font(pygame.font.get_default_font(), gFontSize)

# Functions
def printScore():
    lTextSurface = gFont.render("Score: " + str(gScore), True, gColorText)
    gScreen.blit(lTextSurface, dest=(gScreenSizeX/2-(lTextSurface.get_width() /2), gFontSize))

def wait():
    global gSnakeXPositions, gSnakeYPositions, gScore
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                print("QUIT")
                pygame.quit()
                #sys.exit()
            if event.type == pygame.KEYDOWN: #and event.key == K_f:
                print("KEYDOWN")
                gSnakeXPositions=list()
                gSnakeYPositions=list()
                gSnakeXPositions.append(int(gScreenSizeX/2)-1) # origin is top left
                gSnakeYPositions.append(int(gScreenSizeY/2)-1) # we are starting in the middle of the surface
                gScore=0
                return

# Main
while gRunning:
    # poll for events
    # pygame.QUIT event means the user clicked X to close your window
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            gRunning = False

    # Read keyboard event and set coordinates of head (new rect)
    lKeys = pygame.key.get_pressed()
    if lKeys[pygame.K_w] or lKeys[pygame.K_UP]: #up
        print("up")
        gDirection="up"
    if lKeys[pygame.K_s] or lKeys[pygame.K_DOWN]: #down
        print("down")
        gDirection="down"
    if lKeys[pygame.K_a] or lKeys[pygame.K_LEFT]: #left
        print("left")
        gDirection="left"
    if lKeys[pygame.K_d] or lKeys[pygame.K_RIGHT]: #right
        print("right")
        gDirection="right"

	# move the snake (grow in direction
    if gDirection=="up":
        gSnakeXPositions.insert(0, gSnakeXPositions[0])
        gSnakeYPositions.insert(0, gSnakeYPositions[0]-gRectangleSize)
    elif gDirection=="down":
        gSnakeXPositions.insert(0, gSnakeXPositions[0])
        gSnakeYPositions.insert(0, gSnakeYPositions[0]+gRectangleSize)
    elif gDirection=="left":
        gSnakeXPositions.insert(0, gSnakeXPositions[0]-gRectangleSize)
        gSnakeYPositions.insert(0, gSnakeYPositions[0])
    elif gDirection=="right":
        gSnakeXPositions.insert(0, gSnakeXPositions[0]+gRectangleSize)
        gSnakeYPositions.insert(0, gSnakeYPositions[0])

	# Remove last element
    if gPowerpillCounter==0:
#        print("Popping")
        gSnakeXPositions.pop()
        gSnakeYPositions.pop()
    else:
        gPowerpillCounter-=1
        # dont pop, let snake grow

    # fill the screen with a color to wipe away anything from last frame
    gScreen.fill(gColorBackground)

	# Draw Powerpill
    gPowerpillPositionTemp=pygame.Vector2(gPowerpillPosition.x+gRectangleSize/2, gPowerpillPosition.y+gRectangleSize/2)
    pygame.draw.circle(gScreen, "blue", gPowerpillPositionTemp, gRectangleSize/2/2)

    # Draw snake
    for lI in range(len(gSnakeXPositions)):
        #print("Drawing #" + str(lI) + " ( "+ str(gSnakeXPositions[lI]) + "/)" + str(gSnakeYPositions[lI]))
        pygame.draw.rect(gScreen, "red", pygame.Rect(gSnakeXPositions[lI], gSnakeYPositions[lI], gRectangleSize, gRectangleSize))

    # now print the score
    printScore()

    # flip() the display to put your work on screen
    pygame.display.flip()

    # Check Border hit
    if gSnakeXPositions[0] < 0 or gSnakeXPositions[0] > gScreenSizeX - gRectangleSize or gSnakeYPositions[0] < 0 or gSnakeYPositions[0] > gScreenSizeY-gRectangleSize:
        print("BANG!")
        #gRunning = False
        wait()

# Check powerpill-hit
#    if (abs(gSnakeXPositions[0]-gPowerpillPosition.x) <= gRectangleSize/2) and (abs(gSnakeYPositions[0]-gPowerpillPosition.y) <= gRectangleSize/2):
    print(str(gSnakeXPositions[0]) + "/" + str(gSnakeYPositions[0]))
    if gSnakeXPositions[0]==gPowerpillPosition.x and gSnakeYPositions[0]==gPowerpillPosition.y:
        print("Hit powerpill!")
        gPowerpillPosition=pygame.Vector2(random.randrange(0,gTilesX-1)*gRectangleSize-1, random.randrange(1,gTilesY-1)*gRectangleSize-1)
        gPowerpillCounter=2 # rects to add to snake
        print("gPowerpillPosition: " + str(gPowerpillPosition))
        gScore=gScore+gPowerpillCounter

    gClock.tick(2)  # limit FPS

# Ende & Ergebnis
#wait()
#printScore()

# The End
#pygame.quit()

# Ende
