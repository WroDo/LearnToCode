# Nah: https://docs.python.org/3/howto/curses.html
# Yeah: https://www.pygame.org/docs/
## apt-get install python3-pygame

import pygame
import random

# globals
pygame.init()
gScreenSizeX=640;
gScreenSizeY=480;
gRunning = True
gColorBackground="black"
gColorBall="white"
gColorBorder="white"
gColorText="white"
#gRectangleSize=20
#gSnakeXPositions=list()
#gSnakeYPositions=list()
#gSnakeXPositions.append(319) # origin is top left
#gSnakeYPositions.append(239) # we are starting in the middle of the surface
gBallSize=5
gBallSpeedMax=20
#gTilesX=int(gScreenSizeX / gRectangleSize)
#gTilesY=int(gScreenSizeY / gRectangleSize)
gFontSize=36
gFont = pygame.font.Font(pygame.font.get_default_font(), gFontSize)
gScoreLeft=0
gScoreRight=0
gBallPosition=pygame.Vector2(0,0)
gBallDirection=pygame.Vector2(0,0)

# pygame setup
gScreen = pygame.display.set_mode((gScreenSizeX, gScreenSizeY))
gClock = pygame.time.Clock()

# Functions
def randomizeBall():
    global gBallDirection, gBallPosition, gBallSpeedMax, gScreenSizeX, gScreenSizeY
    gBallPosition=pygame.Vector2(int(gScreenSizeX/2), int(gScreenSizeY/2))
    gBallDirection=pygame.Vector2(int(random.randrange(1,gBallSpeedMax)), int(random.randrange(1,gBallSpeedMax)))
#    print("foo: "+str(random.randrange(0,2)))
#    print("foo: "+str(random.randrange(0,2)))
    if round(random.randrange(0,2)) == 0:
        gBallDirection.x=-gBallDirection.x
    if round(random.randrange(0,2)) == 0:
        gBallDirection.y=-gBallDirection.y

# Main
randomizeBall()
print("gBallPosition: " + str(gBallPosition))
while gRunning:
    # poll for events
    # pygame.QUIT event means the user clicked X to close your window
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            gRunning = False

    # Move ball
    gBallPosition=gBallPosition+gBallDirection

    # Hits of vertical bounderies
    if gBallPosition.y <= gBallSize/2 or gBallPosition.y >= gScreenSizeY-gBallSize/2:
        gBallDirection.y=-gBallDirection.y

    # Hits of horizontal bounderies
    if gBallPosition.x <= gBallSize/2 or gBallPosition.x >= gScreenSizeX-gBallSize/2:
        # Count scores
        if gBallPosition.x <= gBallSize/2:
            gScoreRight+=1
        else:
            gScoreLeft+=1
        # New ball
        randomizeBall()


    # fill the screen with a color to wipe away anything from last frame
    gScreen.fill(gColorBackground)

    # Draw vertical borders
    pygame.draw.line(gScreen, gColorBorder, pygame.Vector2(0, 0), pygame.Vector2(gScreenSizeX-1, 0), 1)
    pygame.draw.line(gScreen, gColorBorder, pygame.Vector2(0, gScreenSizeY-1), pygame.Vector2(gScreenSizeX-1, gScreenSizeY-1), 1)

	# Draw Ball
    pygame.draw.circle(gScreen, gColorBall, gBallPosition, gBallSize)
	
    # now print the scores
    lTextSurface = gFont.render(str(gScoreLeft)+" : "+str(gScoreRight), True, gColorText)
    gScreen.blit(lTextSurface, dest=(gScreenSizeX/2-(lTextSurface.get_width() /2), gFontSize))

    # flip() the display to put your work on screen
    pygame.display.flip()

    gClock.tick(30)  # limit FPS


# The End
pygame.quit()



    

# Ende
